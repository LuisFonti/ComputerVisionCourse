import cv2 as cv
import numpy as np

img = cv.imread('j_blackp.png',0)
kernel = np.ones((5,5),np.uint8)

dilation=cv.dilate(img,kernel,iterations = 2)
erosion = cv.erode(dilation,kernel,iterations = 2)


cv.imshow('imagen original',img)
cv.imshow('erosion',erosion)
cv.imshow('dilation',dilation)
cv.waitKey(0)
cv.destroyAllWindows()
