import  cv2
import numpy as np
cam=cv2.VideoCapture(0)
#Definimos un filtro con dimensiones 5x5 y con valores de 8 bits (0-255)
kernel=np.ones((5,5),np.uint8)
while(True):
    #Ret: detecta si se reciben imagenes o no
    ret, frame=cam.read()
    #Rangos de color en los que el objeto será detectado
    #Ingresar en orden BGR
    rangomax=np.array([120,150,120])
    rangomin=np.array([70,120,100])
    #Máscara binarizada en función del rango definido
    mascara=cv2.inRange(frame,rangomin,rangomax)
    #Transformación morfológica
    opening=cv2.morphologyEx(mascara, cv2.MORPH_OPEN, kernel)
    #Se obtienen los parámetros del rectágulo de detección
    x,y,w,h=cv2.boundingRect(opening)
    cv2.rectangle(frame,(x,y),(x+w,y+h),(0,255,0),3)
    cv2.circle(frame,(int(x+w/2),int(y+h/2)),5,(0,0,255),-1)
    cv2.imshow('camara',frame)
    cv2.imshow('binarizada',mascara)
    cv2.imshow('filtrado',opening)
    k=cv2.waitKey(1) & 0XFF
    if k==27:
        cv2.destroyAllWindows()
        break
