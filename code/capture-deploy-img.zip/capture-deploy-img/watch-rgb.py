import matplotlib.pyplot as plt
import cv2
import numpy as np

image=cv2.imread('opencv_frame_0.png')
print(image.shape)
cv2.imshow("imagen BGR",image)
###
img_rgb = cv2.cvtColor(image, cv2.COLOR_BGR2RGB)
plt.imshow(img_rgb)
###
#plt.imshow(image)
plt.show()
cv2.waitKey(0)
cv2.destroyAllWindows()  
