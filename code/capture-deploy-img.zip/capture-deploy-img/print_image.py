import matplotlib.pyplot as plt
import matplotlib.image as mpimg
img = mpimg.imread('opencv_frame_0.png')
imgplot = plt.imshow(img)
plt.show()
